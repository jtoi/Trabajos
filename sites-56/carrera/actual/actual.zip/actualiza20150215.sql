INSERT INTO evento VALUES (NULL, '10ma. Milla Internacional 2015');
