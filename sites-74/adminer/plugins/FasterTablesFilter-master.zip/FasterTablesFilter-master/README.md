# Faster Tables Filter 
###Adminer plugin
Plugin for [Adminer](http://http://www.adminer.org/ "www.adminer.com") for filtering the tables menu that is faster than the official plugin. Useful when there's way too many tables in the list and AdminerTablesFilter is slow.

To install just add `new FasterTablesFilter` to the `$plugins` array.